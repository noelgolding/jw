
True Type Font: Half Bold Pixel-7 version 1.0


EULA
-==-
The font Half Bold Pixel-7 is freeware for home use only.


DESCRIPTION
-=========-
Original half bold 6*7 pixel font. Native size is 15 points. Latin and Cyrillic code pages are supported.

Files in half_bold_pixel-7.zip:
       	readme.txt     			this file;
        half_bold_pixel-7.ttf    	regular font;
	half_bold_pixel-7_screen.png	preview image.

Please visit http://www.styleseven.com/ for download our other products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


FREEWARE USE (NOTES)
-==================-
Also you may: 
 * Use the font in freeware software (credit needed);
 * Use the font for your education process.


COMMERCIAL OR BUSINESS USE
-========================-
Please contact us ($24.95).
You may:
 * Include the font to your installation;
 * Use one license up to 100 computers in your office.


AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: February 08 2013
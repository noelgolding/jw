
True Type Font: Bubble Pixel-7 version 1.0


EULA
-==-
The Bubble Pixel-7 is freeware for home use only.


DESCRIPTION
-=========-
Original pixel font which has four styles: bubble, dark, hatch, bead.

Files in bubble_pixel-7.zip:
       	readme.txt     			this file;
        bubble_pixel-7.ttf    		bubble style;
	bubble_pixel-7_dark.ttf    	dark style;
	bubble_pixel-7_hatch.ttf    	hatch style;
	bubble_pixel-7_bead.ttf    	bead style;
	bubble_pixel-7.fon   		bubble style in windows "FON" format;
	bubble_pixel-7_dark.fon		dark style in windows "FON" format;
	bubble_pixel-7_hatch.fon	hatch style in windows "FON" format;
	bubble_pixel-7_bead.fon		bead style in windows "FON" format;
	bubble_pixel-7_screen.png	preview image.

Please visit http://www.styleseven.com/ for download our other products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


FREEWARE USE (NOTES)
-=================-
Also you may: 
 * Use the font in freeware software (credit needed);
 * Use the font for your education process.


COMMERCIAL OR BUSINESS USE
-========================-
Please contact us ($24.95).
You may:
 * Include the font to your installation;
 * Use one license up to 100 computers in your office.


AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: December 19 2012